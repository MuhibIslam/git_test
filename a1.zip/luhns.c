#include <stdio.h>

int main(void) {
    int ch;
    int sum_even = 0; /* assume total length even */
    int sum_odd  = 0; /* assume total length odd */
    int count = 0;

    while ((ch = getchar()) >= '0' && ch <= '9') {
        int d = ch - '0';
        count++;

        if (count % 2 == 1) {
            /* odd position from left */
            int x = d * 2;
            if (x >= 10) {
                x -= 9;
            }
            sum_even += x;
            sum_odd  += d;
        } else {
            /* even position from left */
            sum_even += d;
            int x = d * 2;
            if (x >= 10) {
                x -= 9;
            }
            sum_odd += x;
        }
    }

    if (count < 2) {
        printf("Invalid\n");
        return 0;
    }

    int total;

    if (count % 2 == 0) {
        total = sum_even;
    } else {
        total = sum_odd;
    }

    if (total % 10 == 0) {
        printf("Valid\n");
    } else {
        printf("Invalid\n");
    }

    return 0;
}
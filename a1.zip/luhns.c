#include <stdio.h>
/*Cameron Ratte helped me understand
how to make a valid algorithm
that would work by iterating over the whole value
from the leftmost digit*/

int main() {
    int sum1 = 0;
    int sum2 = 0;
    int poscheck = 0;
    int inputsofar = 0;
    int value = 0;

    while (((value = getchar()) >= '0' && value <= '9')) {
        value = value - '0';

        if (poscheck == 1) {
            if (value * 2 >= 10) {
                sum1 = sum1 + (value * 2 - 9);
                }
            else {
                sum1 += (value * 2);
            sum2 += value;
            }  
            }
        
        else {
            if (value * 2 >= 10) {
                sum2 += (value * 2 - 9);
                }
            else {
                sum2 += (value * 2);
            sum1 += value;
        }
        }

        poscheck = 1 - poscheck;
        inputsofar = value;
    }

    if (poscheck == 1) {
        sum1 = sum2;
    }

    if ((sum1*9) % 10 == inputsofar) {
        printf("Valid\n");
    } else {
        printf("Invalid\n");
    }

    return 0;
}